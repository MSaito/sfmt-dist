#pragma once
#ifndef SFMT_DIST_H
#define SFMT_DIST_H

#include "config.h"
#include "debug.h"

#endif // SFMT_DIST_H
