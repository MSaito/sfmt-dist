#pragma once
#ifndef SFMT_DIST_VERSION_H
#define SFMT_DIST_VERSION_H

namespace MersenneTwister {
    const char * get_sfmt_dist_version();
}

#endif // SFMT_DIST_VERSION_H
