#include "sfmt-dist.h"

namespace MersenneTwister {
    const char * get_sfmt_dist_version()
    {
        return VERSION;
    }
}
